#!/usr/bin/env ts-node
/**
 * Phase 0 — Environment Audit
 * Checks: Node version, Python + PyMuPDF, FFmpeg, TypeScript compiler, Remotion CLI.
 * Exits 0 on pass, 1 on any failure — used as a CI gate.
 */

import { execSync, ExecSyncOptions } from "child_process";
import * as fs from "fs";
import * as path from "path";

interface CheckResult {
  name: string;
  status: "PASS" | "FAIL" | "WARN";
  detail: string;
}

const results: CheckResult[] = [];

function run(cmd: string): string {
  try {
    const opts: ExecSyncOptions = { stdio: "pipe", encoding: "utf8" };
    return (execSync(cmd, opts) as unknown as string).trim();
  } catch {
    return "";
  }
}

function check(name: string, cmd: string, validator: (out: string) => boolean, detail: (out: string) => string): void {
  const out = run(cmd);
  const passed = validator(out);
  results.push({
    name,
    status: passed ? "PASS" : "FAIL",
    detail: detail(out),
  });
}

function warn(name: string, cmd: string, validator: (out: string) => boolean, detail: (out: string) => string): void {
  const out = run(cmd);
  const passed = validator(out);
  results.push({
    name,
    status: passed ? "PASS" : "WARN",
    detail: detail(out),
  });
}

// ─── Node.js ─────────────────────────────────────────────────────────────────
check(
  "Node.js >= 20",
  "node --version",
  (v) => {
    const match = v.match(/v(\d+)/);
    return match ? parseInt(match[1] ?? "0") >= 20 : false;
  },
  (v) => v || "not found",
);

// ─── npm ─────────────────────────────────────────────────────────────────────
check(
  "npm",
  "npm --version",
  (v) => v.length > 0,
  (v) => v || "not found",
);

// ─── TypeScript ───────────────────────────────────────────────────────────────
check(
  "TypeScript >= 5",
  "npx tsc --version",
  (v) => {
    const match = v.match(/(\d+)\./);
    return match ? parseInt(match[1] ?? "0") >= 5 : false;
  },
  (v) => v || "not found",
);

// ─── Remotion CLI ─────────────────────────────────────────────────────────────
warn(
  "Remotion CLI (needs npm ci first)",
  "npx remotion --version",
  (v) => v.includes("4.") || v.includes("remotion"),
  (v) => v || "run npm ci first",
);

// ─── Python ───────────────────────────────────────────────────────────────────
check(
  "Python >= 3.9",
  "python --version",
  (v) => {
    const match = v.match(/Python (\d+)\.(\d+)/);
    if (!match) return false;
    const major = parseInt(match[1] ?? "0");
    const minor = parseInt(match[2] ?? "0");
    return major >= 3 && minor >= 9;
  },
  (v) => v || "not found — needed for PDF extraction",
);

// ─── PyMuPDF ─────────────────────────────────────────────────────────────────
warn(
  "PyMuPDF (fitz)",
  "python -c \"import fitz; print(fitz.version)\"",
  (v) => v.length > 0 && !v.includes("Error"),
  (v) => v || "not installed — run: pip install pymupdf",
);

// ─── FFmpeg ───────────────────────────────────────────────────────────────────
check(
  "FFmpeg",
  "ffmpeg -version",
  (v) => v.includes("ffmpeg version"),
  (v) => (v ? v.split("\n")[0] ?? "" : "not found"),
);

// ─── package.json present ────────────────────────────────────────────────────
const pkgExists = fs.existsSync(path.join(process.cwd(), "package.json"));
results.push({
  name: "package.json",
  status: pkgExists ? "PASS" : "FAIL",
  detail: pkgExists ? "found" : "missing",
});

// ─── Print report ─────────────────────────────────────────────────────────────
console.log("\n━━━ Phase 0 Environment Audit ━━━━━━━━━━━━━━━━━━━━\n");
for (const r of results) {
  const icon = r.status === "PASS" ? "✓" : r.status === "WARN" ? "⚠" : "✗";
  console.log(`  ${icon}  [${r.status}]  ${r.name.padEnd(30)} ${r.detail}`);
}

const failures = results.filter((r) => r.status === "FAIL");
const warnings = results.filter((r) => r.status === "WARN");

console.log(
  `\n  ${results.length - failures.length - warnings.length} passed · ${warnings.length} warnings · ${failures.length} failed\n`,
);

if (failures.length > 0) {
  console.error("Phase 0 FAILED — fix the above before proceeding to Phase 1.");
  process.exit(1);
} else {
  console.log("Phase 0 PASSED — environment is ready for Phase 1 render.\n");
  process.exit(0);
}
