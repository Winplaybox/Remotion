# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Purpose

PDF2Shorts Studio converts research PDFs and authoritative technical documentation into original Hinglish educational YouTube Shorts and Instagram Reels (1080×1920, max 180s). Channel niche: AI, Technology & Future Explained. Target: 2 approved videos/day via GitHub Actions rendering with mandatory human approval before publishing.

## Tech Stack

- **Runtime**: Node.js LTS + TypeScript (strict mode)
- **Video**: Remotion + React
- **3D**: Three.js / React Three Fiber (reserved for hero scenes only)
- **2.5D**: CSS transforms + SVG (default for most scenes)
- **PDF**: PyMuPDF (Python) with pdf.js fallback
- **Validation**: Zod for all schemas
- **Audio**: FFmpeg for processing; TTS via adapter interface
- **Automation**: GitHub Actions (scheduled + manual dispatch)

## Common Commands

```bash
# Install dependencies
npm ci

# Type checking
npm run typecheck

# Lint
npm run lint

# Tests
npm run test

# Run a single test file
npm run test -- path/to/file.test.ts

# Local Remotion preview
npm run remotion:preview

# Local render (single composition)
npm run render -- --composition=<id>

# PDF extraction (Python)
python -m packages.research.extract --input research/incoming/<file.pdf>

# Daily audit (manual trigger)
npm run audit:scheduled
```

## Repository Structure

```
pdf2shorts-studio/
├── packages/
│   ├── core/          # Shared types, schemas (Zod), utilities
│   ├── research/      # PDF ingestion, extraction, source registry
│   ├── editorial/     # Topic scoring, duplicate detection, script generation
│   ├── storyboard/    # Scene JSON generation, timing validation, asset manifests
│   ├── media/         # TTS adapter, audio processing, caption alignment
│   ├── remotion/      # Compositions, reusable scene components, design system
│   ├── quality/       # Automated QC validators
│   └── analytics/     # Platform metrics, performance reporting
├── automation/        # Orchestrator scripts run by GitHub Actions
├── schemas/           # Shared Zod schemas (research, topic, script, storyboard, video)
├── research/          # incoming/ → extracted/ → processed/ → registry/
├── content/           # topics/ → scripts/ → storyboards/ → approved/ / rejected/
├── assets/            # images/, models/, fonts/, audio/, generated/
├── output/            # previews/, rendered/
└── .github/workflows/ # ci.yml, daily-audit.yml, render-approved.yml, weekly-report.yml
```

## Architecture Principles

**Claude does**: research interpretation, script writing, storyboard generation, SEO suggestions, weekly performance interpretation.  
**Code does**: PDF extraction, OCR, duplicate detection, timing math, subtitle validation, rendering, audio mixing, analytics calculations.

Never use Claude for deterministic work. Never run deterministic checks through Claude.

## Core Data Contract

Every video flows through a `VideoContent` record with a strict `workflowStatus` state machine:

```
research → script-review → storyboard-review → render-ready
→ rendered → quality-review → approved → published / rejected
```

Any material change to script or visuals **invalidates prior approval** — a new review cycle is required. Publishing is always a manual, separate action.

## Content Rules

1. Every factual claim must have a traceable source (document, URL, page, section).
2. Never invent statistics, citations, or research findings.
3. Never treat an AI-generated explanation as verified evidence.
4. Write original scripts — never reproduce a PDF verbatim.
5. Natural Hinglish narration; preserve English technical terms (API, OAuth, GPU, etc.).
6. Target 120–175s; measure from actual audio duration, not word count.
7. Detect and reject duplicate topics before generating scripts.

## Remotion Design System

Build and reuse components from these families — do not create one-off scene code:

`CinematicIntro` · `CinematicOutro` · `SpatialTypography` · `KineticCaptions` · `FloatingCards` · `DataVisualization` · `ProcessFlow` · `NeuralNetworkScene` · `CodeVisualization` · `CameraRig` · `ParallaxLayers` · `SceneTransition` · `AudioTimeline`

Use **2D/2.5D layers by default**. Reserve Three.js / React Three Fiber for important explanatory hero moments only — headless WebGL on GitHub runners must be validated early.

## Narration Adapter

TTS is injected through a `NarrationProvider` interface. Never hardcode a TTS vendor. Implement the interface first with file-import support; add a live provider only after voice quality is approved.

## GitHub Actions

- **Daily audits** run at 08:00 and 18:00 IST (`Asia/Kolkata` timezone in cron).
- **Rendering** is `workflow_dispatch` only — requires an approved `videoId`, never a free-form prompt.
- Pin all third-party Actions to full commit SHAs before production use.
- Treat scheduled run times as targets, not guarantees (GitHub queues under load).

## Cost Controls

- Cache all PDF extraction results; never re-extract unchanged documents.
- Batch AI calls: one consolidated morning call for content, one evening call for analytics.
- No separate AI agent per audit — GitHub Actions runs deterministic checks itself.
- Do not introduce paid dependencies without documenting value and recurring cost.

## Implementation Phases (do not skip ahead)

| Phase | Gate |
|-------|------|
| 0 | Environment audit — confirm Node, Python, FFmpeg, GitHub Actions WebGL support |
| 1 | Working Remotion test render (local + CI artifact) |
| 2 | PDF extraction → structured research JSON |
| 3 | Editorial engine → 3 reviewed scripts from one PDF |
| 4 | Storyboard engine → valid scene JSON |
| 5 | Media engine → narrated video with captions |
| 6 | Visual design system → 3 videos from shared components |
| 7 | Cloud render + QC → downloadable validated MP4 |
| 8 | Analytics + daily automation workflow |

After each phase: summarize changes, list modified files, report test results, identify limitations, then **wait for approval** before the next phase.

## Research Collections (initial backlog)

| Collection | Sources |
|------------|---------|
| AI fundamentals | Stanford AI Index, Attention Is All You Need paper |
| AI safety | NIST AI RMF |
| Cybersecurity | OWASP Top 10 |
| Internet engineering | IETF RFCs, MDN Web Docs |
