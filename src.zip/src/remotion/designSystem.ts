/**
 * Central design system tokens — every component imports from here.
 * Change values here; all scenes update automatically.
 */
export const DESIGN = {
  colors: {
    // Backgrounds
    bgDeep: "#07090E",       // CAD grid base
    bgSurface: "#0D1117",    // Card surfaces
    bgElevated: "#161B22",   // Elevated panels

    // Text
    textPrimary: "#F0F6FF",
    textSecondary: "#8B9BAF",
    textMuted: "#4A5568",

    // Accent
    accent: "#4A9EFF",       // Primary blue
    accentWarm: "#FF6B35",   // Data highlight orange
    accentGreen: "#00D084",  // Positive metric
    accentRed: "#FF4D6A",    // Alert / negative
    accentPurple: "#9B5DE5", // AI/neural theme

    // Data viz palette (colorblind-safe, 6 stops)
    dataPalette: [
      "#4A9EFF", // blue
      "#FF6B35", // orange
      "#00D084", // green
      "#9B5DE5", // purple
      "#F7C59F", // peach
      "#3DBCF6", // cyan
    ],

    // Grid & structure
    gridLine: "rgba(74,158,255,0.08)",
    gridLineBright: "rgba(74,158,255,0.18)",
    divider: "rgba(240,246,255,0.08)",
  },

  fonts: {
    display: '"Inter", "Helvetica Neue", Arial, sans-serif',
    sans: '"Inter", "Helvetica Neue", Arial, sans-serif',
    mono: '"JetBrains Mono", "Fira Code", "Consolas", monospace',
  },

  // 9:16 safe zones (1080×1920)
  safeZone: {
    top: 160,
    bottom: 160,
    left: 72,
    right: 72,
    contentWidth: 936,   // 1080 - 72*2
  },

  // Easing presets for spring()
  springs: {
    snappy: { damping: 22, stiffness: 180, mass: 0.8 },
    smooth: { damping: 28, stiffness: 120, mass: 1.0 },
    heavy:  { damping: 18, stiffness: 80,  mass: 1.4 },
    bouncy: { damping: 12, stiffness: 200, mass: 0.7 },
  },

  // Layer Z-index conventions
  z: {
    gridBg: 0,
    contentBase: 10,
    cards: 20,
    overlay: 30,
    captions: 40,
    hud: 50,
  },
} as const;

export type DesignColor = keyof typeof DESIGN.colors;
